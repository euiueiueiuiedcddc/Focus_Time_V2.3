# FocusTimeLock — a native macOS lock-mode companion

A small menu-bar-only app (no Dock icon) that does what a website fundamentally
can't: while it's "locked," it blocks the Escape key system-wide, turns off
the three/four-finger trackpad swipe gestures that open Mission Control or
switch Spaces, and force-quits System Settings if you try to open it to turn
any of this off — then restores/re-allows all of it automatically when the
timer ends.

**Read this before you rely on it for anything:** this was written from a
Linux machine with no Mac available, so it has never actually been compiled
or run. The code is a real, careful implementation of the standard macOS
techniques for this (a CGEventTap for the key, `defaults` + a Dock restart
for the trackpad gestures) — not a mockup — but you are the first person to
actually build and test it. Start with the 1-minute test lock before trusting
it with anything longer, and don't rely on the emergency unlock working
perfectly on the first try until you've verified it yourself.

## What it actually does

- Blocks every Escape key press, system-wide, in every app — not just your
  browser — for as long as the lock is active. This is the only way to stop
  a browser's "press Esc to leave fullscreen" behavior, because browsers
  deliberately make that unblockable from inside a web page.
- Disables the three/four-finger trackpad swipe gestures (Mission
  Control / Spaces switching) for the same duration, by changing your own
  trackpad preference settings and restarting the Dock. Your Dock will
  blink out and back in for a second when a lock starts and ends — that's
  expected, not a crash. Right after enabling this, the app reads the
  settings back to confirm the write actually took effect (see the honesty
  note in `TrackpadGestures.swift`) and warns you — without stopping the
  lock — if it couldn't confirm that.
- Force-quits System Settings (or System Preferences, depending on your
  macOS version) the instant it's launched or brought to the front while
  locked, so going there to flip off this app's Accessibility permission
  isn't a way around the lock either. There can be a brief flash of its
  window before it's closed — there's no way to block the launch itself
  before it happens, only react immediately once it does.
- Requires you to grant it **two** separate permissions once, through the
  real macOS system prompts — Accessibility (System Settings → Privacy &
  Security → Accessibility) AND Input Monitoring (same place, → Input
  Monitoring). No app can skip or auto-grant either — they're deliberate
  macOS security requirements, not something this app is choosing to make
  you do. Both are checked before every lock starts, not just once: if
  either is ever missing, FocusTimeLock tells you plainly that keyboard
  shortcuts aren't blocked yet and refuses to start the timer, rather than
  starting a countdown that isn't actually locking anything. **Input
  Monitoring is the one almost everyone misses** — it's a separate toggle
  from Accessibility that macOS has required since Catalina for anything
  that taps system-wide key events, and it's easy to grant Accessibility,
  see the menu bar icon turn into 🔒, and assume you're done. See
  "Escape still works even though it says Locked" below if that happens to
  you.
- Has two ways out before the timer ends:
  1. **"I'm done — show proof to unlock"**, in the menu. Gated exactly like
     the website's own hold-to-end control: it stays disabled (showing a
     countdown, "Unlock available in 18:42") until **25 real minutes** have
     elapsed, and even then it only unlocks once you pick a photo through a
     file-chooser dialog. Being honest about what that checks: the app
     confirms you selected an image file. It has no way to verify the photo
     is actually of real work — that's not something a local app can
     meaningfully enforce (you could pick any old photo), so treat it as a
     deliberate speed bump and a record you're building for yourself, not
     real verification. The photo gets copied to
     `~/Documents/FocusTimeLock Proofs/` with a timestamp, so you end up
     with an actual log over time.
  2. **Hold Control + Option + Command + Escape together for 3 full
     seconds** — a quick tap of Escape alone is swallowed and does nothing.
     This one is **not** gated behind the 25 minutes, on purpose, even
     though that wasn't asked for: a lock with genuinely zero immediate way
     out for anyone, ever, is a real hazard (an actual emergency, a bug in
     this code, needing to shut the Mac down right now), so there's always
     one deliberate, hard-to-trigger-by-accident escape hatch that isn't
     conditional on anything. If you want this removed too, say so and I
     will, but I'd rather you make that call knowingly than have me quietly
     ship something with no safety valve at all.
- Does **not** touch anything outside the Escape key, those specific
  trackpad gestures, and System Settings. Every other key, Cmd+Tab, Mission
  Control's own keyboard shortcut (F3/Control+Up by default), Activity
  Monitor, force-quit, etc. all still work normally. If you want more
  blocked, see "Extending it" below.
- Runs a tiny local status server on `127.0.0.1:47655` for as long as the
  app is open (not just while locked), so the FocusTime *website* can show
  "System lock: On/Off" on a teacher's or parent's roster. It only answers
  `{"locked":true}` or `{"locked":false}` — nothing else — and is bound to
  the loopback interface, so nothing outside this Mac can ever reach it.
  This is entirely optional: the app and the lock work exactly the same
  with or without the website ever asking. See "Connecting to the
  website's roster" below.

## Building and running it

1. Install Xcode from the Mac App Store if you don't already have it (free).
2. Unzip this project, then either:
   - Double-click `Package.swift` — it opens directly in Xcode as a Swift
     Package, or
   - Open Xcode, choose **File → Open…**, and select the
     `focustime-lock` folder.
3. Pick the `FocusTimeLock` scheme (top left of the Xcode window, next to
   the Run/Stop buttons) and hit **Run** (▶ or Cmd+R).
4. The app has no window — look for a small dot icon (⏺) in your menu bar,
   top right of the screen. That's it running.
5. Click the icon → "Grant Accessibility permission…". macOS will pop up a
   system dialog and/or take you straight to System Settings → Privacy &
   Security → Accessibility. Find the app in that list (it may be listed as
   "FocusTimeLock" or just show up after you click the **+** button and
   browse to the built binary — Xcode's console output will show you the
   exact build path if it's not auto-listed) and switch it on.
6. Click the icon again → **"Grant Input Monitoring permission…"** — this is
   a separate item from step 5, easy to skip, and the lock genuinely does
   not work without it. Same pattern: macOS takes you to System Settings →
   Privacy & Security → Input Monitoring, find/add FocusTimeLock there, and
   switch it on.
7. Click the menu bar icon once more and check both permission lines now
   read "granted ✓" before moving on.
8. Click the menu bar icon → "Start 1-minute test lock" and confirm:
   Escape does nothing, a three-finger swipe doesn't open Mission Control,
   and opening System Settings (Spotlight, Dock, however you'd normally get
   there) closes itself immediately. Wait for the minute to elapse and
   confirm everything comes back/works again automatically. Only once
   that's confirmed should you trust a longer lock.
9. Separately, test the emergency hold (Control+Option+Command+Escape for
   3 seconds) during that same 1-minute lock, so you know it genuinely
   works before you're depending on it.

**Testing the 25-minute + photo flow without waiting 25 minutes:** the gate
is one line — `static let minimumLockSeconds: TimeInterval = 25 * 60` near
the top of `LockController.swift`. Temporarily change it to something like
`30` seconds, rebuild, confirm the "I'm done — show proof to unlock" item
enables itself and the file picker + copy-to-`~/Documents/FocusTimeLock
Proofs` actually works, then change it back to `25 * 60` and rebuild before
using it for real.

Running it via Xcode keeps it alive only while Xcode is attached in some
configurations — if you want it to keep running after closing Xcode, use
**Product → Archive**, or just run the built binary directly from
`~/Library/Developer/Xcode/DerivedData/.../Build/Products/Debug/FocusTimeLock`
(Xcode's console output after a build shows the exact path).

## Connecting to the website's roster

If you've set up the website's optional real cross-device sync (see its own
setup notes — it needs a free Firebase project and a shared Sync code), a
teacher's or parent's roster can show whether a student's/kid's Mac
currently has the system-level lock on, live. For that to work:

1. This app needs to actually be running and open on that person's Mac
   while they're focusing — it's a separate, standalone piece from the
   website on purpose (a webpage alone can never reach anything at this
   level), so starting a lock *here* is still a manual step, not something
   the website can trigger for you (see "Extending it" below for how that
   could change in the future).
2. Open the website in a normal browser tab on the same Mac. It polls
   `http://127.0.0.1:47655/status` every few seconds while a focus session
   is running on the website side, and reports whatever this app answers.
3. To check it's working before relying on it: with this app running, open
   `http://127.0.0.1:47655/status` directly in a browser tab on the same
   Mac — you should see `{"locked":false}` (or `true` during a lock). If
   that page doesn't load at all, something's blocking the port (another
   app using it, or a firewall) — see the honesty note at the top of
   `StatusServer.swift`.
4. If the website's roster still doesn't show a lock status for a
   particular person after that, open that browser's DevTools console —
   if `fetch` to `127.0.0.1` is being blocked for some reason on your
   specific macOS/Chrome version, it'll show up there as a concrete error
   to search for, rather than a silent "Unknown."

## Escape still works even though it says Locked

If you started a lock, the menu bar shows 🔒 with a countdown, and Escape
still exits fullscreen or otherwise does something — this almost always
means Input Monitoring permission (not Accessibility) was never actually
granted to the binary that's currently running. Earlier versions of this
app only checked Accessibility before starting, which is why a lock could
claim to be running while silently blocking nothing; that's fixed now (a
lock refuses to start at all unless both permissions are confirmed AND the
key block installs successfully), but if you're seeing this on an app you
built before that fix, or the permission itself has gone stale, here's how
to clear it up:

1. Click the menu bar icon and check both permission lines. If either says
   anything other than "granted ✓", that's the actual problem — grant it via
   the matching menu item and try the lock again.
2. If both already say "granted ✓" and Escape *still* isn't blocked, the
   permission entry itself is probably stale — this happens a lot with
   Swift Package Manager apps because every rebuild produces a technically
   different binary, and macOS's permission grant can end up pointing at
   the old one. Fix: open System Settings → Privacy & Security →
   Accessibility, select FocusTimeLock, and remove it with the **"–"**
   button; do the same under → Input Monitoring. Quit the app, rebuild it,
   relaunch, and grant both permissions again from scratch.
3. Still stuck after that: quit the app completely (not just closing a
   window — use "Quit FocusTimeLock" from its own menu, or Activity
   Monitor), then relaunch it fresh before granting permissions again. A
   permission granted to a process that's already running sometimes doesn't
   take effect until that process restarts.

## If the trackpad gestures don't actually turn off

The `defaults` preference keys Apple uses for these gestures have shifted
across macOS versions, and I had no way to verify the exact current ones for
your specific macOS version from here. If `TrackpadGestures.swift`'s keys
turn out to be wrong on your Mac, here's the 2-minute fix:

1. In Terminal, run:
   ```
   defaults read com.apple.AppleMultitouchTrackpad > /tmp/before.txt
   ```
2. Go to System Settings → Trackpad → More Gestures, and manually toggle off
   "Swipe between full-screen apps" (and/or "Mission Control" under the
   trackpad settings, depending on your macOS version's wording).
3. Run the same command again:
   ```
   defaults read com.apple.AppleMultitouchTrackpad > /tmp/after.txt
   diff /tmp/before.txt /tmp/after.txt
   ```
4. Whatever key(s) the diff shows changed are the real ones for your
   system — update the `keys` array in `TrackpadGestures.swift` to match,
   rebuild, and re-run.

## Honest limits (same spirit as the website's own README)

- This blocks the *gesture* and the Escape *key*. It does not and cannot
  prevent you from shutting down or force-restarting your Mac, booting into
  Safe Mode or Recovery, or physically walking away. No software can
  prevent a determined person with physical access to their own machine
  from eventually getting around a self-imposed lock — that's true of Cold
  Turkey and Freedom too, not a gap specific to this.
- It only blocks Escape and the swipe gestures — if your actual goal is
  "can't switch apps at all," that's a much bigger (and riskier) ask
  involving blocking Cmd+Tab, Mission Control's keyboard shortcut, etc.
  Happy to extend it if you want that, but each additional blocked shortcut
  is one more way you could lock yourself out awkwardly if something goes
  wrong, so I kept the default scope to exactly what you asked for.
- If the app crashes or is force-quit while locked (Activity Monitor, for
  example), your trackpad settings could be left in the "disabled" state
  since the restore step never ran. If that ever happens: System Settings →
  Trackpad → re-enable the gestures manually — a 10-second fix, not
  permanent damage.

## Extending it

- To block additional keys (e.g., Cmd+Tab), add their virtual key codes to
  the check in `KeyBlocker.swift`'s `handle(type:event:)` — macOS key codes
  are a fixed table (Escape is 53, Tab is 48, etc.), searchable online as
  "macOS virtual key codes".
- To tie this to the FocusTime *website* automatically (so starting a
  session there also starts the Mac-level lock) would need a custom URL
  scheme (e.g., `focustimelock://start?minutes=50`) that the site opens via
  `window.location` when you hit "Begin" — that's a real feature I can add
  on both sides if you want it; I kept this version standalone/manual to
  start.
