import Cocoa
import UniformTypeIdentifiers

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusItem: NSStatusItem!
    private let lock = LockController()
    // Runs for as long as the app is open (not just while locked) so the
    // website's roster can tell "not locked" apart from "the native app
    // isn't running at all" — see StatusServer.swift.
    private let statusServer = StatusServer()

    private var stopMenu: NSMenuItem!
    private var statusMenu: NSMenuItem!
    private var permissionMenu: NSMenuItem!
    private var inputMonitoringMenu: NSMenuItem!

    func applicationDidFinishLaunching(_ notification: Notification) {
        // Menu-bar-only app: no Dock icon, no app switcher entry.
        NSApp.setActivationPolicy(.accessory)

        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        statusItem.button?.title = "⏺"

        let menu = NSMenu()

        statusMenu = NSMenuItem(title: "Not locked", action: nil, keyEquivalent: "")
        statusMenu.isEnabled = false
        menu.addItem(statusMenu)
        menu.addItem(.separator())

        permissionMenu = NSMenuItem(
            title: "Grant Accessibility permission…",
            action: #selector(requestPermission),
            keyEquivalent: ""
        )
        permissionMenu.target = self
        menu.addItem(permissionMenu)

        // A second, separate permission Escape-blocking needs on modern
        // macOS — see KeyBlocker.swift's big comment. Listed as its own menu
        // item specifically because it's the one people don't know to look
        // for, and missing it is the single most likely reason Escape would
        // still work despite everything looking "locked."
        inputMonitoringMenu = NSMenuItem(
            title: "Grant Input Monitoring permission…",
            action: #selector(requestInputMonitoringPermissionMenuAction),
            keyEquivalent: ""
        )
        inputMonitoringMenu.target = self
        menu.addItem(inputMonitoringMenu)
        menu.addItem(.separator())

        for minutes in [1, 25, 50, 90] {
            let label = minutes == 1 ? "Start 1-minute test lock" : "Start \(minutes)-minute lock"
            let item = NSMenuItem(title: label, action: #selector(startLock(_:)), keyEquivalent: "")
            item.target = self
            item.tag = minutes
            menu.addItem(item)
        }

        stopMenu = NSMenuItem(
            title: "Unlock available in 25:00",
            action: #selector(requestOrdinaryUnlock),
            keyEquivalent: ""
        )
        stopMenu.target = self
        stopMenu.isEnabled = false
        menu.addItem(stopMenu)

        menu.addItem(.separator())
        menu.addItem(NSMenuItem(
            title: "Emergency unlock: hold ⌃⌥⌘+Esc for 3s",
            action: nil,
            keyEquivalent: ""
        ))
        menu.addItem(.separator())
        menu.addItem(NSMenuItem(title: "Quit FocusTimeLock", action: #selector(quit), keyEquivalent: "q"))

        statusItem.menu = menu

        lock.onTick = { [weak self] text in
            guard let self = self else { return }
            self.statusItem.button?.title = "🔒 \(text)"
            self.statusMenu.title = "Locked — \(text) left"
            self.updateUnlockMenuItem()
        }
        lock.onStateChange = { [weak self] locked in
            self?.updateMenuForLockState(locked)
        }
        lock.onEmergencyUnlock = { [weak self] in
            self?.showAlert(
                title: "Emergency unlock used",
                message: "The lock was released early via the Control+Option+Command+Escape hold."
            )
        }
        lock.onOrdinaryUnlock = { [weak self] in
            self?.showAlert(
                title: "Unlocked",
                message: "Saved a copy of the photo to ~/Documents/FocusTimeLock Proofs and released the lock."
            )
        }
        lock.onTrackpadVerificationFailed = { [weak self] in
            self?.showAlert(
                title: "Trackpad gestures may not be blocked",
                message: "The Escape key and System Settings are still blocked, but FocusTimeLock couldn't confirm the trackpad-swipe block took effect on this macOS version. See the README's \"If the trackpad gestures don't actually turn off\" section — the lock is still running either way."
            )
        }

        updatePermissionMenuState()

        statusServer.isLocked = { [weak self] in self?.lock.isLocked ?? false }
        statusServer.start()
    }

    func applicationWillTerminate(_ notification: Notification) {
        statusServer.stop()
        // Safety net for scenario: something terminates the app gracefully
        // (SIGTERM) while it's locked, bypassing the "Quit" menu item's own
        // block. Restores trackpad gestures so they don't stay disabled
        // forever. This cannot run during a hard kill (`kill -9` / Activity
        // Monitor's "Force Quit") — no process can intercept that signal, by
        // design, so that case is still only fixed by manually re-enabling
        // the gestures in System Settings (see the README).
        if lock.isLocked {
            lock.stop(reason: .appTerminating)
        }
    }

    private func updateMenuForLockState(_ locked: Bool) {
        statusItem.button?.title = locked ? "🔒" : "⏺"
        statusMenu.title = locked ? "Locked" : "Not locked"
        for item in statusItem.menu?.items ?? [] where item.action == #selector(startLock(_:)) {
            item.isEnabled = !locked
        }
        if !locked {
            stopMenu.title = "Unlock available in 25:00"
            stopMenu.isEnabled = false
        }
    }

    /// Keeps the "show proof to unlock" menu item's title and enabled state
    /// honest about whether the 25-minute gate has actually opened yet —
    /// called every second from lock.onTick while locked.
    private func updateUnlockMenuItem() {
        if lock.canRequestOrdinaryUnlock {
            stopMenu.title = "I'm done — show proof to unlock"
            stopMenu.isEnabled = true
        } else {
            let remaining = LockController.minimumLockSeconds - lock.elapsedSeconds
            stopMenu.title = "Unlock available in \(LockController.format(remaining))"
            stopMenu.isEnabled = false
        }
    }

    private func updatePermissionMenuState() {
        let accessGranted = KeyBlocker.hasAccessibilityPermission
        permissionMenu.title = accessGranted
            ? "Accessibility permission: granted ✓"
            : "Grant Accessibility permission…"
        permissionMenu.isEnabled = !accessGranted

        let inputGranted = KeyBlocker.hasInputMonitoringPermission
        inputMonitoringMenu.title = inputGranted
            ? "Input Monitoring permission: granted ✓"
            : "Grant Input Monitoring permission…"
        inputMonitoringMenu.isEnabled = !inputGranted
    }

    @objc private func requestPermission() {
        KeyBlocker.requestAccessibilityPermission()
        // macOS opens System Settings itself via the prompt. We can't detect
        // the moment permission is actually flipped on without polling, so
        // just recheck shortly after — long enough for someone to glance at
        // System Settings and come back, not a real-time listener.
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            self?.updatePermissionMenuState()
        }
    }

    @objc private func requestInputMonitoringPermissionMenuAction() {
        KeyBlocker.requestInputMonitoringPermission()
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            self?.updatePermissionMenuState()
        }
    }

    /// Checked up front, before the lock starts, and again by LockController
    /// itself as a defensive second check — per the ask: FocusTimeLock should
    /// never start a countdown and pretend to be "locked" while its keyboard
    /// shortcut blocking isn't actually in place yet.
    @objc private func startLock(_ sender: NSMenuItem) {
        guard KeyBlocker.hasAccessibilityPermission else {
            showAlert(
                title: "Keyboard shortcuts aren't blocked yet",
                message: "FocusTimeLock can't block the Escape key without Accessibility permission, so it won't start the timer until that's granted. Use \"Grant Accessibility permission…\" in this menu, then try starting the lock again."
            )
            requestPermission()
            return
        }
        guard KeyBlocker.hasInputMonitoringPermission else {
            showAlert(
                title: "One more permission needed",
                message: "Accessibility is granted, but macOS also requires Input Monitoring permission to actually block the Escape key — this is the one most people miss, since it's a separate toggle from Accessibility. Use \"Grant Input Monitoring permission…\" in this menu, approve it in System Settings, then try starting the lock again."
            )
            requestInputMonitoringPermissionMenuAction()
            return
        }
        if let failure = lock.start(minutes: sender.tag) {
            switch failure {
            case .accessibilityPermissionMissing:
                // Rare race: permission was revoked between the check above
                // and this call. Same message, same refusal to start.
                showAlert(
                    title: "Keyboard shortcuts aren't blocked yet",
                    message: "Accessibility permission was revoked just now, so FocusTimeLock won't start the timer. Grant it again from the menu first."
                )
                requestPermission()
            case .inputMonitoringPermissionMissing:
                showAlert(
                    title: "Keyboard shortcuts aren't blocked yet",
                    message: "Input Monitoring permission was revoked just now, so FocusTimeLock won't start the timer. Grant it again from the menu first."
                )
                requestInputMonitoringPermissionMenuAction()
            case .eventTapFailed:
                showAlert(
                    title: "Couldn't install the Escape-key block",
                    message: "Both permissions look granted, but macOS still refused to install the key block — this usually means a stale permission entry left over from an earlier build of this app. Open System Settings → Privacy & Security → Accessibility (and → Input Monitoring), remove FocusTimeLock from both lists using the \"–\" button, then use this menu to grant them again from scratch before retrying."
                )
            }
        }
    }

    /// The ordinary (non-emergency) way out: only reachable once 25 minutes
    /// have actually elapsed, and only completes if a photo is picked.
    @objc private func requestOrdinaryUnlock() {
        guard lock.canRequestOrdinaryUnlock else { return } // menu item should already be disabled; this is a defensive no-op

        let panel = NSOpenPanel()
        panel.title = "Show proof of your work to unlock"
        panel.message = "Pick a photo of what you worked on. Being honest about what this checks: the app confirms you picked an image file — it has no way to verify the photo is actually of real work, so treat this as a deliberate speed bump, not real verification."
        panel.prompt = "Unlock"
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        if #available(macOS 11.0, *) {
            panel.allowedContentTypes = [.image]
        } else {
            panel.allowedFileTypes = ["png", "jpg", "jpeg", "heic", "gif", "tiff", "bmp"]
        }

        panel.begin { [weak self] response in
            guard let self = self, response == .OK, let url = panel.url else { return }
            self.saveProofCopy(of: url)
            self.lock.attemptOrdinaryUnlock()
        }
    }

    /// Copies the chosen photo into a local, dated folder so there's an
    /// actual record over time — nothing is uploaded anywhere, since this
    /// app has no server and none of this is sent to FocusTime's website.
    private func saveProofCopy(of url: URL) {
        let fm = FileManager.default
        guard let docs = fm.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let folder = docs.appendingPathComponent("FocusTimeLock Proofs", isDirectory: true)
        do {
            try fm.createDirectory(at: folder, withIntermediateDirectories: true)
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"
            let ext = url.pathExtension.isEmpty ? "jpg" : url.pathExtension
            let dest = folder.appendingPathComponent("\(formatter.string(from: Date())).\(ext)")
            try fm.copyItem(at: url, to: dest)
        } catch {
            NSLog("FocusTimeLock: couldn't save proof copy — \(error)")
            // Not fatal — the unlock still proceeds either way; this is a
            // nice-to-have record, not something to block you over.
        }
    }

    @objc private func quit() {
        if lock.isLocked {
            showAlert(
                title: "Still locked",
                message: "Use the emergency unlock (hold ⌃⌥⌘+Esc for 3 seconds) before quitting, so your trackpad gestures get restored properly."
            )
            return
        }
        NSApp.terminate(nil)
    }

    private func showAlert(title: String, message: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = message
        alert.runModal()
    }
}
