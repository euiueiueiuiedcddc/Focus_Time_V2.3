import Cocoa

/// Owns the actual "am I locked right now" state: starts/stops the key
/// blocker and trackpad-gesture disabling together, runs the countdown,
/// and reports status text back up to the menu bar item.
///
/// There are exactly three ways a lock ends:
///  1. The chosen timer runs all the way down (`.timerElapsed`).
///  2. 25 minutes have elapsed AND the person provides a photo through the
///     "show proof to unlock" flow (`.ordinaryUnlockWithProof`) — gated the
///     same way the website's own hold-to-end control is gated.
///  3. The Control+Option+Command+Escape 3-second hold (`.emergency`) — this
///     one is NOT gated behind the 25 minutes on purpose. It's a genuine
///     safety valve (an actual emergency, a bug, needing to shut the Mac
///     down right now), and shipping a lock with zero immediate way out for
///     anyone, ever, isn't something I'm willing to do even though it
///     wasn't explicitly asked for — see the README.
final class LockController {
    private(set) var isLocked = false
    private var remainingSeconds: Int = 0
    private var lockStartedAt: Date?
    private var timer: Timer?
    private var savedTrackpadDefaults: [String: String] = [:]
    private let keyBlocker = KeyBlocker()
    private let systemSettingsBlocker = SystemSettingsBlocker()

    /// The website gates its own "hold to end" control behind 25 real
    /// minutes of focus time; this mirrors that exactly.
    static let minimumLockSeconds: TimeInterval = 25 * 60

    /// Called every second while locked, with human-readable remaining time.
    var onTick: ((String) -> Void)?
    /// Called when a lock starts or ends, for any reason.
    var onStateChange: ((Bool) -> Void)?
    /// Called if the emergency hold-to-unlock fires early.
    var onEmergencyUnlock: (() -> Void)?
    /// Called when the person unlocks early via the 25-minute + photo flow.
    var onOrdinaryUnlock: (() -> Void)?
    /// Called (non-fatally) if the trackpad-gesture disable couldn't be
    /// verified right after a lock starts — see TrackpadGestures.swift.
    var onTrackpadVerificationFailed: (() -> Void)?

    init() {
        keyBlocker.onEmergencyUnlock = { [weak self] in
            self?.stop(reason: .emergency)
        }
    }

    enum StopReason {
        case timerElapsed
        case emergency
        case ordinaryUnlockWithProof
        /// Used only for best-effort cleanup if the app is asked to terminate
        /// gracefully (SIGTERM) while locked. Deliberately silent — no alert,
        /// since there's no time to run a modal dialog during termination,
        /// and this can't catch a hard `kill -9` / Force Quit anyway (no
        /// process can intercept that, ever).
        case appTerminating
    }

    var elapsedSeconds: TimeInterval {
        guard let start = lockStartedAt else { return 0 }
        return Date().timeIntervalSince(start)
    }

    /// Whether the person is currently allowed to open the "show proof to
    /// unlock" picker at all. AppDelegate should keep that menu item
    /// disabled until this is true.
    var canRequestOrdinaryUnlock: Bool {
        isLocked && elapsedSeconds >= Self.minimumLockSeconds
    }

    enum StartFailure {
        /// Escape-key blocking depends entirely on this permission, so a
        /// lock without it would silently do nothing. The caller must tell
        /// the person and refuse to start — never start a "lock" that
        /// doesn't actually lock anything.
        case accessibilityPermissionMissing
        /// The second, easy-to-miss permission Escape-blocking also needs
        /// on modern macOS — see the big comment in KeyBlocker.swift. Most
        /// people will hit THIS one, not the Accessibility one above, since
        /// Accessibility is the one every "allow this app to control your
        /// computer" tutorial mentions and Input Monitoring is the one that
        /// isn't obvious at all.
        case inputMonitoringPermissionMissing
        /// Both permissions were granted, but installing the actual event
        /// tap still failed (rare — e.g. a stale permission grant left over
        /// from an earlier build of this app, which is why the alert this
        /// produces tells people to remove and re-add it in System Settings
        /// rather than just "try again").
        case eventTapFailed
    }

    /// A lock only ever starts if the thing it absolutely depends on
    /// (both permissions, and the event tap actually installing) is
    /// confirmed first — never silently starts a countdown that isn't
    /// actually locking anything. Returns the failure reason so the caller
    /// can show a specific message; returns nil on success.
    @discardableResult
    func start(minutes: Int) -> StartFailure? {
        guard !isLocked else { return nil }

        guard KeyBlocker.hasAccessibilityPermission else {
            KeyBlocker.requestAccessibilityPermission()
            // Permission can't be granted instantly — it requires the person
            // to go toggle it on in System Settings. Bail out of starting a
            // lock that wouldn't actually block anything yet; they can press
            // Start again once it's granted.
            return .accessibilityPermissionMissing
        }
        guard KeyBlocker.hasInputMonitoringPermission else {
            KeyBlocker.requestInputMonitoringPermission()
            return .inputMonitoringPermissionMissing
        }

        // Install the actual key block BEFORE claiming to be locked at all —
        // if this fails, nothing below should run, and isLocked must stay
        // false. This is what an earlier version of this file got wrong:
        // it set isLocked = true and started the countdown unconditionally,
        // then called keyBlocker.start() without checking whether it
        // actually succeeded.
        guard keyBlocker.start() else {
            return .eventTapFailed
        }

        isLocked = true
        remainingSeconds = max(1, minutes) * 60
        lockStartedAt = Date()

        savedTrackpadDefaults = TrackpadGestures.snapshot()
        TrackpadGestures.disable()
        if !TrackpadGestures.verifyDisabled() {
            // Best-effort only — see TrackpadGestures.swift's honesty note.
            // This doesn't block starting the lock (Escape-blocking, the
            // one guaranteed protection, is already confirmed above), but
            // the person should know this specific piece might not actually
            // be in effect on their macOS version.
            NSLog("FocusTimeLock: trackpad-gesture disable did not verify — see TrackpadGestures.swift's README section")
            onTrackpadVerificationFailed?()
        }
        systemSettingsBlocker.start()

        onStateChange?(true)
        tick() // fire once immediately so the menu shows the full duration right away

        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.tick()
        }
        return nil
    }

    private func tick() {
        onTick?(Self.format(Double(remainingSeconds)))
        if remainingSeconds <= 0 {
            stop(reason: .timerElapsed)
            return
        }
        remainingSeconds -= 1
    }

    /// Called by AppDelegate only after it has already collected a photo
    /// through the proof picker. Re-checks the 25-minute gate itself rather
    /// than trusting the caller, since this is the one path that's supposed
    /// to have a real condition attached to it.
    @discardableResult
    func attemptOrdinaryUnlock() -> Bool {
        guard canRequestOrdinaryUnlock else { return false }
        stop(reason: .ordinaryUnlockWithProof)
        return true
    }

    func stop(reason: StopReason) {
        guard isLocked else { return }
        isLocked = false
        lockStartedAt = nil

        timer?.invalidate()
        timer = nil

        keyBlocker.stop()
        systemSettingsBlocker.stop()
        TrackpadGestures.restore(savedTrackpadDefaults)
        savedTrackpadDefaults = [:]

        onStateChange?(false)
        switch reason {
        case .emergency: onEmergencyUnlock?()
        case .ordinaryUnlockWithProof: onOrdinaryUnlock?()
        case .timerElapsed, .appTerminating: break
        }
    }

    static func format(_ totalSeconds: Double) -> String {
        let s = max(0, Int(totalSeconds.rounded()))
        return String(format: "%02d:%02d", s / 60, s % 60)
    }
}
