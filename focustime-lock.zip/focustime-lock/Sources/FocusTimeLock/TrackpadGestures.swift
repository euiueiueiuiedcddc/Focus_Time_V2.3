import Foundation

/// Disables/restores the three- and four-finger trackpad swipe gestures that
/// trigger Mission Control / Spaces switching, by editing the user's own
/// `defaults` preference domains and then restarting the Dock (the process
/// that reads these prefs live).
///
/// IMPORTANT HONESTY NOTE: the exact `defaults` keys Apple uses for these
/// gestures have shifted across macOS releases, and this was written and
/// never tested on a real Mac (this project was built from a Linux machine
/// with no macOS available). The keys below are the commonly-documented
/// ones as of recent macOS versions. If disabling doesn't actually stop the
/// swipe gesture on your Mac, see the "Finding the right defaults key"
/// section in the README — it's a 2-minute manual diagnostic using
/// `defaults read` before/after toggling the setting in System Settings
/// yourself, and you just swap the key name(s) below.
enum TrackpadGestures {
    static let domains = [
        "com.apple.AppleMultitouchTrackpad",                  // built-in trackpad
        "com.apple.driver.AppleBluetoothMultitouch.trackpad", // external/Bluetooth trackpad
    ]

    static let keys = [
        "TrackpadThreeFingerHorizSwipeGesture",
        "TrackpadFourFingerHorizSwipeGesture",
        "TrackpadFourFingerVertSwipeGesture",
    ]

    /// Reads and returns the current value of every (domain, key) pair so
    /// `restore()` can put things back exactly as they were, rather than
    /// guessing at a default.
    static func snapshot() -> [String: String] {
        var values: [String: String] = [:]
        for domain in domains {
            for key in keys {
                if let value = runDefaults(["read", domain, key]) {
                    values["\(domain)|\(key)"] = value
                }
                // if `defaults read` prints nothing / errors, there's simply no
                // explicit override yet — restore() will `delete` the key in
                // that case, putting it back to "unset" rather than inventing
                // a value that might not match the system default.
            }
        }
        return values
    }

    static func disable() {
        for domain in domains {
            for key in keys {
                _ = runDefaults(["write", domain, key, "-int", "0"])
            }
        }
        restartDock()
    }

    /// Reads every (domain, key) pair back and confirms it now says "0".
    /// IMPORTANT, same honesty point as the big comment at the top of this
    /// file: this only proves the `defaults write` round-tripped through
    /// the preferences database successfully (catches `defaults`/`killall`
    /// being missing, permission errors, etc.) — it does NOT prove the
    /// actual trackpad gesture is disabled in real use, since `defaults
    /// write` happily creates a key that doesn't match anything real if the
    /// names above are wrong for your macOS version. Treat a `true` here as
    /// "the write didn't fail," not as a hardware-verified guarantee.
    static func verifyDisabled() -> Bool {
        for domain in domains {
            for key in keys {
                guard runDefaults(["read", domain, key]) == "0" else { return false }
            }
        }
        return true
    }

    static func restore(_ saved: [String: String]) {
        for domain in domains {
            for key in keys {
                let id = "\(domain)|\(key)"
                if let value = saved[id] {
                    _ = runDefaults(["write", domain, key, "-int", value])
                } else {
                    _ = runDefaults(["delete", domain, key])
                }
            }
        }
        restartDock()
    }

    /// The Dock process reads these prefs at launch, so it has to be
    /// restarted for a change to take effect immediately. macOS relaunches
    /// it automatically within a second or two — you'll see it blink out
    /// and back in.
    private static func restartDock() {
        let task = Process()
        task.launchPath = "/usr/bin/killall"
        task.arguments = ["Dock"]
        try? task.run()
    }

    @discardableResult
    private static func runDefaults(_ args: [String]) -> String? {
        let task = Process()
        task.launchPath = "/usr/bin/defaults"
        task.arguments = args
        let outPipe = Pipe()
        task.standardOutput = outPipe
        task.standardError = Pipe() // swallow "does not exist" noise
        do {
            try task.run()
            task.waitUntilExit()
            guard task.terminationStatus == 0 else { return nil }
            let data = outPipe.fileHandleForReading.readDataToEndOfFile()
            return String(data: data, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)
        } catch {
            return nil
        }
    }
}
