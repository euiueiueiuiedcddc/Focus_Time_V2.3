import Network
import Foundation

/// A minimal local HTTP server so the FocusTime *website* (running in a
/// normal browser, not this app) can ask "is the Mac-level lock on right
/// now?" and show that on a teacher/parent's roster — this is the piece
/// that makes the website's "System lock: On/Off" roster field real
/// instead of guesswork. Deliberately tiny: it answers every request with
/// the same fixed JSON body, `{"locked":true}` or `{"locked":false}`,
/// regardless of path or method. Runs for as long as the app is open, not
/// just while actually locked, so the website can tell "not locked" apart
/// from "FocusTimeLock isn't running at all" (the fetch simply fails in
/// that second case).
///
/// Bound to the loopback interface only (`requiredInterfaceType = .loopback`),
/// so nothing outside this Mac — no other device on the same Wi-Fi, for
/// instance — can ever reach it. That's a real constraint enforced by
/// Network.framework, not a convention this code just happens to follow.
///
/// HONESTY NOTE, same spirit as the rest of this project: this was written
/// and never run, because no Mac was available while building it (see the
/// top-level README). Network.framework's `NWListener`/`NWConnection` APIs
/// used below are real and documented, not invented, but this exact
/// combination hasn't been exercised against a real browser. The one thing
/// worth knowing in advance: current Chrome treats `http://127.0.0.1` as a
/// "potentially trustworthy" origin, so a `fetch()` from the website (which
/// is served over https on GitHub Pages) to this server should NOT be
/// blocked as mixed content — that's a standard, documented browser
/// exception for loopback addresses, not a hack — but if the roster's live
/// status never appears, open the browser's console first; see the
/// README's testing steps for what to check next.
final class StatusServer {
    static let port: NWEndpoint.Port = 47655
    private var listener: NWListener?
    private let queue = DispatchQueue(label: "FocusTimeLock.StatusServer")

    /// Polled fresh on every incoming request — always reflects the real
    /// current state, never a stale cached value.
    var isLocked: () -> Bool = { false }

    func start() {
        guard listener == nil else { return }
        do {
            let params = NWParameters.tcp
            params.requiredInterfaceType = .loopback
            params.allowLocalEndpointReuse = true
            let l = try NWListener(using: params, on: Self.port)
            l.newConnectionHandler = { [weak self] connection in self?.handle(connection) }
            l.stateUpdateHandler = { state in
                if case .failed(let error) = state {
                    NSLog("FocusTimeLock: StatusServer failed — \(error). The lock itself is unaffected; only the website's live \"system lock\" roster field won't have data.")
                }
            }
            l.start(queue: queue)
            listener = l
        } catch {
            NSLog("FocusTimeLock: StatusServer couldn't start on port \(Self.port) — \(error). Most likely something else on this Mac is already using that port. The lock itself still works; only the website's live roster status is affected.")
        }
    }

    func stop() {
        listener?.cancel()
        listener = nil
    }

    private func handle(_ connection: NWConnection) {
        connection.start(queue: queue)
        // The request itself is never parsed — every connection gets the
        // identical response, so there's nothing to read beyond noticing
        // that data arrived.
        connection.receive(minimumIncompleteLength: 1, maximumLength: 8192) { [weak self] _, _, _, error in
            guard let self = self, error == nil else { connection.cancel(); return }
            let body = "{\"locked\":\(self.isLocked())}"
            let response =
                "HTTP/1.1 200 OK\r\n" +
                "Content-Type: application/json\r\n" +
                "Content-Length: \(body.utf8.count)\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: no-store\r\n" +
                "Connection: close\r\n\r\n" +
                body
            connection.send(content: response.data(using: .utf8), completion: .contentProcessed({ _ in
                connection.cancel()
            }))
        }
    }
}
