import Cocoa
import ApplicationServices
import IOKit.hid

/// Installs a system-wide CGEventTap that swallows the Escape key so it
/// can never reach any app (including exiting a browser's fullscreen mode)
/// while locked. This requires the app to be granted Accessibility access
/// in System Settings — there's no way around that prompt; macOS requires
/// the person to flip it on by hand, by design, so that no app can silently
/// take over the keyboard without the user knowing.
///
/// There are actually TWO separate macOS permissions involved, and this was
/// the single most likely reason an earlier version of this app could look
/// like it was locked (menu bar shows 🔒, countdown running) while Escape
/// still did nothing to stop it:
///   1. Accessibility (Privacy & Security → Accessibility) — checked via
///      AXIsProcessTrusted(). Already required by the rest of this file.
///   2. Input Monitoring (Privacy & Security → Input Monitoring) — a
///      SEPARATE permission macOS has required since Catalina for any app
///      that taps system-wide keyDown/keyUp events, checked via
///      IOHIDCheckAccess. Granting only #1 and not #2 (an easy thing to miss,
///      since nothing before this file ever asked for #2) lets tapCreate()
///      below still succeed and look fine, while macOS quietly never
///      delivers it any key events at all — so every Escape press sails
///      straight through, with zero error anywhere. Both are now checked
///      before a lock is allowed to start — see LockController.swift.
///
/// A deliberate safety valve is built in: holding Control+Option+Command
/// together with Escape for a full 3 seconds calls `onEmergencyUnlock`.
/// A plain, quick tap of Escape does nothing but get swallowed.
final class KeyBlocker {
    private var eventTap: CFMachPort?
    private var runLoopSource: CFRunLoopSource?
    private var emergencyWorkItem: DispatchWorkItem?

    /// Called once the 3-second emergency hold completes.
    var onEmergencyUnlock: (() -> Void)?

    private let escapeKeyCode: Int64 = 53
    private let emergencyHoldSeconds: Double = 3.0

    static var hasAccessibilityPermission: Bool {
        AXIsProcessTrusted()
    }

    /// Shows the system "FocusTimeLock wants to control this computer"
    /// prompt if permission hasn't been granted yet. Returns the
    /// permission state at the moment of calling (it will still be false
    /// right after the prompt appears — the person has to go flip it on in
    /// System Settings > Privacy & Security > Accessibility, then come back).
    @discardableResult
    static func requestAccessibilityPermission() -> Bool {
        let options: NSDictionary = [kAXTrustedCheckOptionPrompt as String: true]
        return AXIsProcessTrustedWithOptions(options as CFDictionary)
    }

    /// See the big comment above — this is the easy-to-miss second
    /// permission. IOHIDCheckAccess never shows its own system prompt by
    /// itself; requestInputMonitoringPermission() below triggers that.
    static var hasInputMonitoringPermission: Bool {
        IOHIDCheckAccess(kIOHIDRequestTypeListenEvent) == kIOHIDAccessTypeGranted
    }

    /// Triggers macOS's "FocusTimeLock would like to receive keystrokes"
    /// prompt the first time it's called for this binary, same hand-off
    /// pattern as requestAccessibilityPermission(): the person has to go
    /// flip it on in System Settings themselves, then come back.
    @discardableResult
    static func requestInputMonitoringPermission() -> Bool {
        IOHIDRequestAccess(kIOHIDRequestTypeListenEvent)
    }

    /// Returns true only if the tap was actually created and installed —
    /// never claim success (and never let LockController mark itself
    /// "locked") unless Escape is genuinely, verifiably about to be
    /// swallowed from here on.
    @discardableResult
    func start() -> Bool {
        guard KeyBlocker.hasAccessibilityPermission else {
            NSLog("FocusTimeLock: no Accessibility permission, cannot install key blocker")
            return false
        }
        guard KeyBlocker.hasInputMonitoringPermission else {
            NSLog("FocusTimeLock: no Input Monitoring permission, cannot install key blocker")
            return false
        }

        let mask: CGEventMask =
            (1 << CGEventType.keyDown.rawValue) |
            (1 << CGEventType.keyUp.rawValue) |
            (1 << CGEventType.flagsChanged.rawValue)

        let selfPtr = Unmanaged.passUnretained(self).toOpaque()

        guard let tap = CGEvent.tapCreate(
            tap: .cgSessionEventTap,
            place: .headInsertEventTap,
            options: .defaultTap, // .defaultTap (not .listenOnly) is required to actually swallow events
            eventsOfInterest: mask,
            callback: { _, type, event, refcon in
                guard let refcon = refcon else { return Unmanaged.passUnretained(event) }
                let blocker = Unmanaged<KeyBlocker>.fromOpaque(refcon).takeUnretainedValue()
                return blocker.handle(type: type, event: event)
            },
            userInfo: selfPtr
        ) else {
            NSLog("FocusTimeLock: failed to create event tap")
            return false
        }

        eventTap = tap
        runLoopSource = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, tap, 0)
        CFRunLoopAddSource(CFRunLoopGetCurrent(), runLoopSource, .commonModes)
        CGEvent.tapEnable(tap: tap, enable: true)
        return true
    }

    func stop() {
        if let tap = eventTap {
            CGEvent.tapEnable(tap: tap, enable: false)
        }
        if let source = runLoopSource {
            CFRunLoopRemoveSource(CFRunLoopGetCurrent(), source, .commonModes)
        }
        eventTap = nil
        runLoopSource = nil
        cancelEmergencyCountdown()
    }

    private func handle(type: CGEventType, event: CGEvent) -> Unmanaged<CGEvent>? {
        // If macOS ever disables our tap (it does this if the callback takes
        // too long, or sometimes after the screen locks/unlocks), re-enable
        // it immediately rather than silently losing the block.
        if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
            if let tap = eventTap { CGEvent.tapEnable(tap: tap, enable: true) }
            return Unmanaged.passUnretained(event)
        }

        guard type == .keyDown || type == .keyUp || type == .flagsChanged else {
            return Unmanaged.passUnretained(event)
        }

        let flags = event.flags
        let comboModifiersHeld = flags.contains(.maskControl)
            && flags.contains(.maskAlternate)
            && flags.contains(.maskCommand)

        if type == .keyDown {
            let keyCode = event.getIntegerValueField(.keyboardEventKeycode)
            guard keyCode == escapeKeyCode else {
                // Only Escape is blocked — everything else passes through untouched.
                return Unmanaged.passUnretained(event)
            }
            if comboModifiersHeld {
                armEmergencyCountdownIfNeeded()
            } else {
                cancelEmergencyCountdown()
            }
            return nil // swallow every Escape key-down, combo or not
        }

        if type == .keyUp {
            let keyCode = event.getIntegerValueField(.keyboardEventKeycode)
            if keyCode == escapeKeyCode {
                cancelEmergencyCountdown()
                return nil // swallow the matching key-up too
            }
            return Unmanaged.passUnretained(event)
        }

        // .flagsChanged: releasing Control, Option, or Command early cancels
        // the countdown even if Escape itself is still physically held down.
        if type == .flagsChanged, !comboModifiersHeld {
            cancelEmergencyCountdown()
        }
        return Unmanaged.passUnretained(event)
    }

    private func armEmergencyCountdownIfNeeded() {
        guard emergencyWorkItem == nil else { return }
        let item = DispatchWorkItem { [weak self] in
            self?.emergencyWorkItem = nil
            self?.onEmergencyUnlock?()
        }
        emergencyWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + emergencyHoldSeconds, execute: item)
    }

    private func cancelEmergencyCountdown() {
        emergencyWorkItem?.cancel()
        emergencyWorkItem = nil
    }
}
