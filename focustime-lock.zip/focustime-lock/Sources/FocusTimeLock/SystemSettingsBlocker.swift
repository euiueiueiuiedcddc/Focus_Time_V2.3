import Cocoa

/// While locked, force-quits System Settings (or the older System
/// Preferences) the instant it's launched or brought to the front — so
/// going to flip off this app's own Accessibility permission isn't a way
/// around the lock either.
///
/// HONESTY NOTE, same spirit as `TrackpadGestures.swift`: Apple renamed
/// System Preferences to System Settings in macOS Ventura, and I wrote this
/// from a Linux machine with no Mac to confirm the exact bundle identifier
/// on your specific macOS version. The candidates below are my best effort
/// (and the name-based fallback should catch it either way), but if it
/// still manages to open, open Activity Monitor while it's up, find its
/// exact process name, and add it to `candidateNameFragments` below.
///
/// Also honest about a real limit: there can be a brief flash of its window
/// before it's force-quit, since this reacts to the app launching rather
/// than preventing the launch outright — there's no supported, unprivileged
/// way to block a launch before it happens on macOS.
final class SystemSettingsBlocker {
    private let candidateBundleIdentifiers: Set<String> = [
        "com.apple.systempreferences",
        "com.apple.SystemSettings",
        "com.apple.Settings",
    ]
    private let candidateNameFragments = ["system settings", "system preferences"]

    private var launchObserver: NSObjectProtocol?
    private var activateObserver: NSObjectProtocol?

    func start() {
        let center = NSWorkspace.shared.notificationCenter
        launchObserver = center.addObserver(
            forName: NSWorkspace.didLaunchApplicationNotification,
            object: nil,
            queue: .main
        ) { [weak self] note in self?.handle(note) }

        activateObserver = center.addObserver(
            forName: NSWorkspace.didActivateApplicationNotification,
            object: nil,
            queue: .main
        ) { [weak self] note in self?.handle(note) }

        // Catch it even if it was already open before the lock started.
        for app in NSWorkspace.shared.runningApplications where isTargeted(app) {
            app.forceTerminate()
        }
    }

    func stop() {
        let center = NSWorkspace.shared.notificationCenter
        if let observer = launchObserver { center.removeObserver(observer) }
        if let observer = activateObserver { center.removeObserver(observer) }
        launchObserver = nil
        activateObserver = nil
    }

    private func handle(_ note: Notification) {
        guard let app = note.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication,
              isTargeted(app) else { return }
        app.forceTerminate()
    }

    private func isTargeted(_ app: NSRunningApplication) -> Bool {
        if let id = app.bundleIdentifier, candidateBundleIdentifiers.contains(id) {
            return true
        }
        if let name = app.localizedName?.lowercased() {
            return candidateNameFragments.contains { name.contains($0) }
        }
        return false
    }
}
