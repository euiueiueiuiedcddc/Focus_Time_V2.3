// swift-tools-version:5.7
import PackageDescription

let package = Package(
    name: "FocusTimeLock",
    platforms: [.macOS(.v12)],
    targets: [
        .executableTarget(
            name: "FocusTimeLock",
            path: "Sources/FocusTimeLock"
        )
    ]
)
